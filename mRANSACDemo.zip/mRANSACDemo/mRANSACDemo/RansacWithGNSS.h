#pragma once
#include"rtklib.h"
#include <memory>
#include <set>
#include <vector>
constexpr int sampleSize = 4 + ENACMP + ENAGAL + ENAGLO + ENAIRN;//sampleSize>=estimateNum
constexpr int estimateNum = 4 + ENACMP + ENAGAL + ENAGLO + ENAIRN;//the size of params
class RansacWithGNSS
{
public:
	double max_iterations_;
	double  min_iterations_;
	double probability_;
	double ransac_p;
	double threshold;
	bool sort_by_p;
	bool reCal;
	RansacWithGNSS();
	int satIndexBest[sampleSize] = { 0 };
	double best_model_value_;
	double best_error_;
	int thresholdMethod;//0:manual 1:auto
	double multiThreshold;
	int checkType;//criterion default: number of satellites 1:posterior variance with weights  2: satellite weights 3: spatial accuracy factor 4: posterior variance
	bool useCoRelation;
	bool useSys;
	bool useSample;
	bool locOpt;//Locally Optimized
	bool useDOP;
	double bestDx[estimateNum];
	int min_true_itr;
	double min_inlier_;//if inlier>=min_inlier&&locOpt 
	std::unique_ptr<bool[]>best_result_;//the result of each sat
	int calRANSAC(double* H, double* V, double* P, double* x,int satNum, double* azel, int* sat, std::vector< std::set<int>>sample,int sys);
	bool calSample(const double* H, const double* V, double* P, int satNum, std::set<int>sample, double* DX=nullptr, double* D0=nullptr);
	bool checkParam(double* H, double* P, double* V, double* D0, int satNum);

private:
	double now_model_value;
	double now_error;
	std::unique_ptr<bool[]>now_result;//the result of each sat
};

