
#include "RansacWithGNSS.h"
#include<iostream>
#include"rtklib.h"
#include <math.h>
#include <algorithm>
#include <limits>
#include <array>
#include <format>
#include <string>
#include<random>
#include<chrono>

constexpr auto TraceLevel = 0;
std::mt19937 rng1(19938);
static int itr_count = 0;
RansacWithGNSS::RansacWithGNSS()
{
	max_iterations_ = 1000;
	min_iterations_ = 100000000;
	min_true_itr = 3;
	threshold = 30;
	multiThreshold = 3.0;
	probability_ = 0.99;
	useSys = useCoRelation = reCal = sort_by_p = locOpt = useDOP = false;
	best_error_ = (std::numeric_limits<double>::max)();
	checkType = thresholdMethod = 0;
	now_model_value = now_error = best_model_value_ = ransac_p = 0.0;
	min_inlier_ = 0.3;
}


bool RansacWithGNSS::checkParam(double* H, double* P, double* V, double* D0, int satNum)
{
	int count;
	switch (checkType)
	{
	case 1:
		count = 0;
		now_model_value = 0;
		now_error = 0;
		for (size_t i = 0; i < satNum; i++)
		{

			if (thresholdMethod == 1)
			{
				double Ai[estimateNum] = { 0 };
				for (size_t j = 0; j < estimateNum; j++)
				{
					Ai[j] = H[i * estimateNum + j];
				}
				double tt[estimateNum]{ 0 };
				double tmp = 0.0;
				matmul("NN", 1, estimateNum, estimateNum, 1, Ai, D0, 0, tt);//Ai*DxAi^T
				matmul("NT", 1, 1, estimateNum, 1, tt, Ai, 0, &tmp);//Ai*DxAi^T
				tmp += 1.0 / (P[i * satNum + i]);
				threshold = sqrt(tmp) * multiThreshold;
			}
			if (abs(V[i]) <= threshold)
			{
				count++;
				now_result[i] = true;
				now_model_value += (V[i] * V[i]);
			}
			else
			{
				now_result[i] = false;
			}
		}

		now_error = sqrt(now_error / count);
		now_model_value = count;
		break;
	default:
		now_model_value = 0;
		now_error = 0;
		for (size_t i = 0; i < satNum; i++)
		{
			now_error = now_error + V[i] * V[i];
			if (abs(V[i]) <= threshold)
			{
				now_model_value++;
				now_result[i] = true;
			}
			else
			{
				now_result[i] = false;
			}
		}
		now_error = now_error / now_model_value;
		break;
	}
	if (now_model_value > best_model_value_ || (now_model_value == best_model_value_ && now_error < best_error_))
	{
		return true;
	}
	return false;
}



bool RansacWithGNSS::calSample(const double* H, const double* V, double* P, int satNum, std::set<int>sample, double* DX, double* D0)
{
	if (DX == nullptr)
		return false;

	double H0[sampleSize * estimateNum] = { 0 }, dx[estimateNum] = { 0 }, V0[sampleSize] = { 0 }, P0[sampleSize * sampleSize] = { 0 };
	std::array<int, sampleSize>S1{0};
	int count = 0;
	for (auto i = sample.begin(); i != sample.end(); i++)
	{
		S1[count++]=(*i);
	}

	for (size_t i = 0; i < sampleSize; i++)
	{
		P0[i * (sampleSize + 1)] = P[S1[i] * (satNum + 1)];
		V0[i] = V[S1[i]];
		for (size_t j = 0; j < estimateNum; j++)
		{
			H0[i * estimateNum + j] = H[S1[i] * estimateNum + j];
		}
	}

	auto info = wlsq(H0, P0, V0, estimateNum, sampleSize, dx, D0);

	if (info)
	{
		return false;
	}
	for (size_t i = 0; i < estimateNum; i++)
	{
		DX[i] = dx[i];
	}
	matinv(D0, estimateNum);
	return true;
}



int RansacWithGNSS::calRANSAC(double* H, double* V, double* P, double* x, int satNum, double* azel, int* sat, std::vector< std::set<int>>sample, int sys)
{

	if (satNum <= sampleSize)
	{
		return 0;
	}
	double* V1 = mat(satNum, 1);
	int k0 = 0, k1 = 0, k3=0;
	auto satCor = new double[satNum * satNum];
	best_result_ = std::make_unique<bool[]>(satNum);
	now_result = std::make_unique<bool[]>(satNum);
	auto calCorre = [](double x1, double y1, double z1, double x2, double y2, double z2) {return (x1 * x2 + y1 * y2 + z1 * z2) / sqrt((x1 * x1 + y1 * y1 + z1 * z1) * (x2 * x2 + y2 * y2 + z2 * z2)); };
	if (1) {
		for (int i = 0; i < satNum; i++)
		{
			satCor[i * satNum + i] = 1.0;
			for (int j = i + 1; j < satNum; j++)
			{
				satCor[j * satNum + i] = satCor[i * satNum + j] = calCorre(H[i * estimateNum], H[i * estimateNum + 1], H[i * estimateNum + 2], H[j * estimateNum], H[j * estimateNum + 1], H[j * estimateNum + 2]);
			}
		}
	}


	double log_probability = log(1.0 - probability_);
	double one_over_indices = 1.0 / static_cast<double> (satNum);

	std::set<std::set<int>>chosen_sub_sets;
	int cur_inti_sub_set_indexs[sampleSize]{0};
	switch (checkType)
	{
	case 0:
		best_model_value_ = 0.0;
		break;
	case 1:
		best_model_value_ =0;
		break;
	case 2:
		best_model_value_ = 0.0;
		break;
	case 3:
		best_model_value_ = 99999.9999;
		break;
	default:
		break;
	}

	std::vector<int> shuffled_indices(satNum);
	int i = 0;

	if (!useSample)
	{
		sample.clear();
	}
	for (auto a : sample)
	{
		++k0;
		std::vector<int>S1;
		S1.reserve(sampleSize);
		for (auto i : a)
		{
			S1.push_back(i);
		}
		//cor
		if (useCoRelation)
		{
			bool bCorr = false;
			do {
				for (i = 0; i < sampleSize; i++)
				{
					for (int j = i + 1; j < sampleSize; j++)
					{
						int index = S1[i] + S1[j] * satNum;
						if (abs(satCor[index]) > 0.95)
						{
							bCorr = true;
							break;
						}
					}
				}
			} while (0);

			if (bCorr)
			{
#if _DEBUG&&TraceLevel

				std::cout << "\r\ncontinue because of correlation\r\n";
#endif
				continue;	
			}
		}

		if (useSys)
		{
			//check sys
			bool bGPS = !(sys & SYS_GPS), bBDS = !(sys & SYS_CMP), bGLO = !(sys & SYS_GLO), bGAL = !(sys & SYS_GAL);
			for (i = 0; i < sampleSize; i++)
			{
				if (satsys(sat[S1[i]], NULL) == SYS_GPS)
					bGPS = true;
				else if (satsys(sat[S1[i]], NULL) == SYS_CMP)
					bBDS = true;
				else if (satsys(sat[S1[i]], NULL) == SYS_GLO)
					bGLO = true;
				else if (satsys(sat[S1[i]], NULL) == SYS_GAL)
					bGAL = true;
			}
			if (!bGPS || !bBDS || !bGLO || !bGAL)
			{
#if _DEBUG&&TraceLevel
				std::cout << "\r\ncontinue because of system\r\n";
#endif
				continue;
			}
		}

		double dx[estimateNum] = { 0 }, D0[estimateNum* estimateNum] = {0};
		auto ret = calSample(H, V, P, satNum, a, dx,D0);
		itr_count++;
		if (!ret)
		{
#if _DEBUG&&TraceLevel
			std::cout << "\r\ncontinue because of calculation\r\n";
#endif
			continue;
		}

		//check


		for (size_t i = 0; i < satNum; i++)
		{
			V1[i] = V[i];
		}
		int count = 0;

		matmul("TN", satNum, 1, estimateNum, 1, H, dx, -1.0, V1);//V=H*Dx-v
		k3++;
		ret = checkParam(H, P, V1, D0, satNum);

	
		if (ret)
		{
			best_model_value_ = now_model_value;
			best_error_ = now_error;
			for (size_t i = 0; i < satNum; i++)
			{
				best_result_[i] = now_result[i];
		}
			for (size_t i = 0; i < sampleSize; i++)
			{
				satIndexBest[i] = S1[i];
			}
			double w = best_model_value_ * one_over_indices;
			double sample_fail = 1.0 - std::pow(w, static_cast<double> (sampleSize));
			std::memmove(bestDx, dx, sizeof(double)* estimateNum);
			sample_fail = (std::max)(std::numeric_limits<double>::epsilon(), sample_fail);
			sample_fail = (std::min)(1.0 - std::numeric_limits<double>::epsilon(), sample_fail);

			min_iterations_ = ceil(log_probability / log(sample_fail));
			while (locOpt &&best_model_value_ >= 0.5 * satNum)
			{
#if _DEBUG&&TraceLevel
				std::cout << "\r\n<< best_model_value_<<\r\n";
#endif
				if (useDOP)
				{
					double dop[4] = { 0 };
					double* temAzel = new double[now_model_value * 2] {0};
					int tempCount = 0;
					for (size_t i = 0; i < satNum; i++)
					{
						if (now_result[i])
						{
							temAzel[2 * tempCount] = azel[i * 2];
							temAzel[2 * tempCount + 1] = azel[i * 2 + 1];
							tempCount++;
						}
					}
					dops(tempCount, temAzel, 0, dop);
					delete[]temAzel;
					if (dop[0] > 3)
					{
						break;
					}
					//check dop
					//extern void dops(int ns, const double* azel, double elmin, double* dop)
				}
				auto tempP = std::make_unique<double[]>(static_cast<size_t>(satNum * satNum));
				auto tempD = std::make_unique<double[]>(static_cast<size_t>(satNum * satNum));
				auto tempV = std::make_unique<double[]>(static_cast<size_t>(satNum));
				for (size_t i = 0; i < satNum; i++)
				{
					tempP[i * satNum + i] = P[i * satNum + i] * now_result[i];
				}
				auto info = wlsq(H, tempP.get(), V, estimateNum, satNum, dx, D0);
				for (size_t i = 0; i < satNum; i++)
				{
					V1[i] = V[i];
				}

				matmul("TN", satNum, 1, estimateNum, 1, H, dx, -1.0, V1);//V=H*Dx-v

				ret = checkParam(H, P, V1, D0, satNum);
#if _DEBUG&&TraceLevel
				std::cout << "\r\n<< best_model_value_<<\r\n";
#endif
				break;
			}
			if (ret)
			{
				best_model_value_ = now_model_value;
				best_error_ = now_error;
				for (size_t i = 0; i < satNum; i++)
				{
					best_result_[i] = now_result[i];
				}
				for (size_t i = 0; i < sampleSize; i++)
				{
					satIndexBest[i] = S1[i];
				}
			}

			//update min_iterations_ 1-(1-w^t)^N=p 
			w = best_model_value_ * one_over_indices;
			sample_fail = 1.0 - std::pow(w, static_cast<double> (sampleSize));
			std::memmove(bestDx, dx, sizeof(double) * estimateNum);
			sample_fail = (std::max)(std::numeric_limits<double>::epsilon(), sample_fail);
			sample_fail = (std::min)(1.0 - std::numeric_limits<double>::epsilon(), sample_fail);

			min_iterations_ = ceil(log_probability / log(sample_fail));
		}
		
	}
	std::random_device rd;
	std::mt19937 rng2(rd());

	while ((k0 < min_iterations_&&k1<10000)|| itr_count< min_true_itr)
	{
		++k0;
		for (i = 0; i < satNum; i++)
		{
			shuffled_indices[i] = i;
		}

		std::shuffle(shuffled_indices.begin(), shuffled_indices.end(), rng2);

		for (i = 0; i < sampleSize; i++)
		{
			cur_inti_sub_set_indexs[i] = shuffled_indices[i];
		}


		std::set<int> tmpi;
		for (i = 0; i < sampleSize; i++)
		{
			tmpi.insert(cur_inti_sub_set_indexs[i]);
		}
#if _DEBUG&&TraceLevel
		std::cout << "\r\n---";
		for (auto it = tmpi.begin(); it != tmpi.end(); it++)
			std::cout << (*it) << " ";
		std::cout << "---\r\n";
#endif
		auto res = chosen_sub_sets.insert(tmpi);
		k1++;
		if (!res.second)//repeat
		{
#if _DEBUG&&TraceLevel

			std::cout << "\r\ncontinue because of repeat\r\n";
#endif // _DEBUG
			if (k1 > 10000)
			{
				break;
			}
			continue;	
		}
			
		if (useSys)
		{
			bool bGPS = !(sys & SYS_GPS), bBDS = !(sys & SYS_CMP), bGLO = !(sys & SYS_GLO), bGAL = !(sys & SYS_GAL);
			for (i = 0; i < sampleSize; i++)
			{
				if (satsys(sat[shuffled_indices[i]], NULL) == SYS_GPS)
					bGPS = true;
				else if (satsys(sat[shuffled_indices[i]], NULL) == SYS_CMP)
					bBDS = true;
				else if (satsys(sat[shuffled_indices[i]], NULL) == SYS_GLO)
					bGLO = true;
				else if (satsys(sat[shuffled_indices[i]], NULL) == SYS_GAL)
					bGAL = true;
			}
			if (!bGPS || !bBDS || !bGLO || !bGAL)
			{
#if _DEBUG&&TraceLevel
				std::cout << "\r\ncontinue because of system\r\n";
#endif 
				continue;	
			}
		}

		if (useCoRelation)
		{
			bool bCorr = false;
			do
			{
				for (i = 0; i < sampleSize; i++)
				{
					for (int j = i + 1; j < sampleSize; j++)
					{
						int index = shuffled_indices[i] + shuffled_indices[j] * satNum;
						if (abs(satCor[index]) > 0.95)
						{
							bCorr = true;
							break;
						}
					}
				}
			} while (0);

			if (bCorr)
			{
#if _DEBUG&&TraceLevel
				std::cout << "\r\ncontinue because of correlation\r\n";
#endif 
				continue;
			}
		}


		double x1[estimateNum] = { 0 };
		double  H0[sampleSize * estimateNum] = { 0 }, dx[estimateNum] = { 0 },  D0[sampleSize * sampleSize] = { 0 };
		itr_count++;
		auto ret = calSample(H, V, P, satNum, tmpi, dx, D0);

		if (!ret)
		{
#if _DEBUG&&TraceLevel
			std::cout << "\r\ncontinue because of calculation\r\n";
#endif
			continue;
		}

		double* V1 = mat(satNum, 1);
		for (size_t i = 0; i < satNum; i++)
		{
			V1[i] = V[i];
		}
		int count = 0;
		double dop[4] = { 0 };
		k3++;
		matmul("TN", satNum, 1, estimateNum, 1, H, dx, -1.0, V1);//V=H*Dx-v
		
		ret = checkParam(H, P, V1, D0, satNum);
		if (ret)
		{
			best_model_value_ = now_model_value;
			best_error_ = now_error;
			for (size_t i = 0; i < satNum; i++)
			{
				best_result_[i] = now_result[i];
			}
			for (size_t i = 0; i < sampleSize; i++)
			{
				satIndexBest[i] = cur_inti_sub_set_indexs[i];
			}
			double w = best_model_value_ * one_over_indices;
			double sample_fail = 1.0 - std::pow(w, static_cast<double> (sampleSize));
			std::memmove(bestDx, dx, sizeof(double)* estimateNum);
			sample_fail = (std::max)(std::numeric_limits<double>::epsilon(), sample_fail);
			sample_fail = (std::min)(1.0 - std::numeric_limits<double>::epsilon(), sample_fail);

			min_iterations_ = ceil(log_probability / log(sample_fail));
			while (locOpt&& best_model_value_>=0.5* satNum)//avoid worse sample
			{
#if _DEBUG&&TraceLevel
				std::cout << "\r\n<< best_model_value_<<\r\n";
#endif

				if (useDOP)
				{
					double dop[4] = { 0 };
					double* temAzel = new double[now_model_value * 2] {0};
					int tempCount = 0;
					for (size_t i = 0; i < satNum; i++)
					{
						if (now_result[i])
						{
							temAzel[2 * tempCount] = azel[i * 2];
							temAzel[2 * tempCount + 1] = azel[i * 2 + 1];
							tempCount++;
						}
					}
					dops(tempCount, temAzel, 0, dop);
					delete[]temAzel;
					if (dop[0] > 3)
					{
						break;
					}
				}
				auto tempP = std::make_unique<double[]>(static_cast<size_t>(satNum * satNum));
				auto tempD = std::make_unique<double[]>(static_cast<size_t>(satNum * satNum));
				auto tempV = std::make_unique<double[]>(static_cast<size_t>(satNum));
				for (size_t i = 0; i < satNum; i++)
				{
					tempP[i * satNum + i] = P[i * satNum + i] * now_result[i];
				}
				auto info = wlsq(H, tempP.get(), V, estimateNum, satNum, dx, D0);
				for (size_t i = 0; i < satNum; i++)
				{
					V1[i] = V[i];
				}

				matmul("TN", satNum, 1, estimateNum, 1, H, dx, -1.0, V1);//V=H*Dx-v

				ret = checkParam(H, P, V1, D0, satNum);
				
#if _DEBUG&&TraceLevel
				std::cout << "\r\n<< best_model_value_<<\r\n";
#endif
				break;
			}

			if (ret)
			{
				best_model_value_ = now_model_value;
				best_error_ = now_error;
				for (size_t i = 0; i < satNum; i++)
				{
					best_result_[i] = now_result[i];
				}
				for (size_t i = 0; i < sampleSize; i++)
				{
					satIndexBest[i] = cur_inti_sub_set_indexs[i];
				}
			}
			//update min_iterations_ 1-(1-w^t)^N=p 
			w = best_model_value_ * one_over_indices;
			sample_fail = 1.0 - std::pow(w, static_cast<double> (sampleSize));
			std::memmove(bestDx, dx, sizeof(double) * estimateNum);
			sample_fail = (std::max)(std::numeric_limits<double>::epsilon(), sample_fail);
			sample_fail = (std::min)(1.0 - std::numeric_limits<double>::epsilon(), sample_fail);

			min_iterations_ = ceil(log_probability / log(sample_fail));
		}

		/*if (now_model_value > best_model_value_ || (now_model_value == best_model_value_ && now_error < best_error_))
		{
#if _DEBUG&&TraceLevel
			std::printf("\r\n---now_model_value: %f \r\n", now_model_value);
			for (auto it = tmp.begin(); it != tmp.end(); it++)
				std::printf("%d  ", (*it));
			std::printf("\r\n");

#endif
			best_model_value_ = now_model_value;
			for (size_t i = 0; i < satNum; i++)
			{
				best_result_[i] = now_result[i];
#if _DEBUG&&TraceLevel
				std::printf(" %.4f ", V1[i]);
#endif
			}
#if _DEBUG&&TraceLevel
			std::printf("\r\n");
#endif
			for (size_t i = 0; i < sampleSize; i++)
			{
				satIndexBest[i] = cur_inti_sub_set_indexs[i];
			}

			double w = static_cast<double> (best_model_value_) * one_over_indices;
			double sample_fail = 1.0 - std::pow(w, static_cast<double> (sampleSize));
			std::memmove(bestDx, dx, sizeof(double) * estimateNum);
			sample_fail = (std::max)(std::numeric_limits<double>::epsilon(), sample_fail);  
			sample_fail = (std::min)(1.0 - std::numeric_limits<double>::epsilon(), sample_fail); 
			min_iterations_ = log_probability / log(sample_fail);

		}
		*/
	}
	if (satCor != nullptr)
	{
		delete[]satCor;
		satCor = nullptr;
	}

	int count = 0;
	for (i = 0; i < satNum; i++)
	{
		if (best_result_[i])
		{
			count++;
		}
	}

	chosen_sub_sets.clear();
	if ((count > satNum * 0.7 && count > estimateNum)|| checkType!=0)
	{
		if (reCal)
		{
			auto LastP = std::make_unique<double[]>(static_cast<size_t>(satNum*satNum));
			auto LastD = std::make_unique<double[]>(static_cast<size_t>(satNum*satNum));
			auto LastV= std::make_unique<double[]>(static_cast<size_t>(satNum));
			for (size_t i = 0; i < satNum; i++)
			{
				LastP[i * satNum + i] = P[i * satNum + i] * best_result_[i];
			}
			auto info = wlsq(H, LastP.get(), V, estimateNum, satNum, bestDx, LastD.get());
		}
		return true;
	}
	return false; 
}

