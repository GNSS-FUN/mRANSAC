#include "rtklib.h"

int input_rtcm3f(rtcm_t* rtcm, FILE* fp)
{
    return 0;
}

int init_rtcm(rtcm_t* rtcm)
{
    return 0;
}

void free_rtcm(rtcm_t* rtcm)
{
}
