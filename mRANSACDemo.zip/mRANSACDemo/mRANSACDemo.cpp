﻿// RANSACDemo.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include"rtklib.h"
#include"RANSACWithGNSS.h"
#include <chrono>
#include <thread>
#include <sstream>
int main()
{
	auto SolOpt = solopt_default;
	auto PrcOpt = prcopt_default;
	SolOpt.timef = 0;
	SolOpt.posf = SOLF_XYZ;
	PrcOpt.nf = 1;
	char* infile[6]{};
	PrcOpt.mode = PMODE_SINGLE;
	PrcOpt.posopt[4] = 0;
	PrcOpt.navsys = SYS_GPS + SYS_CMP * ENACMP + SYS_GAL * ENAGAL + SYS_GLO * ENAGLO;
	PrcOpt.elmin = 10 * D2R;
	PrcOpt.arfilter = 0;
	PrcOpt.rb[0] = -2186030.5166;
	PrcOpt.rb[1] = 5181366.2691;
	PrcOpt.rb[2] = 2999269.8443;
	int robustMode = 2;
#if 1
	infile[0] = (char*)R"(..\datas\DX02200A.21O)";
	infile[1] = (char*)R"(..\datas\DX02200A.21P)";
	gtime_t st{};
	filopt_t FileOpt = { "" };
	for (size_t k = 2; k < 3; k++)
	{
		robustMode = k;
		PrcOpt.outliersnum = 0;
		std::stringstream oss;
		std::string str;
		char* tmpSln;
		if (0 == robustMode)
		{
			PrcOpt.robustopt = 0;
			oss << "..\\datas\\WLSGC4.pos";
		}
		if (1 == robustMode)//IGGIII
		{
			PrcOpt.robustopt = 1;
			PrcOpt.iggiiiparams[0] = 1.5;
			PrcOpt.iggiiiparams[1] = 3;
			oss << "..\\datas\\IGGGC4.pos";
		}
		else if (2 == robustMode)//mRANSAC
		{
			PrcOpt.robustopt = 2;
			oss << "..\\datas\\mRANSACGC1.pos";
		}
		str = oss.str();
		tmpSln = (char*)(str.c_str());
		std::printf("%s\r\n", tmpSln);
		postpos(st, st, 0, 0, &PrcOpt, &SolOpt, &FileOpt, infile, 2, tmpSln, NULL, NULL);
	}



#else

#endif







	return 1;
}

