﻿// RANSACDemo.cpp
//

#include <iostream>
#include"rtklib.h"
#include"RANSACWithGNSS.h"
#include <chrono>
#include <thread>
#include <sstream>

int main()
{

	auto SolOpt = solopt_default;
	auto PrcOpt = prcopt_default;
	SolOpt.timef = 0;
	SolOpt.posf = SOLF_XYZ;
	PrcOpt.nf = 1;
	char* infile[6]{};
	PrcOpt.mode = PMODE_SINGLE;
	PrcOpt.posopt[4] = 0;
	PrcOpt.navsys = SYS_GPS + SYS_CMP * ENACMP + SYS_GAL * ENAGAL + SYS_GLO * ENAGLO;
	PrcOpt.elmin = 0 * D2R;
	PrcOpt.arfilter = 0;
	PrcOpt.rb[0] = -2186030.5166;
	PrcOpt.rb[1] = 5181366.2691;
	PrcOpt.rb[2] = 2999269.8443;
	int robustMode = 2;
#if 1
	infile[0] = (char*)R"(..\datas\DX02200A.21O)";
	infile[1] = (char*)R"(..\datas\DX02200A.21P)";
	gtime_t st{};
	filopt_t FileOpt = { "" };
	for (size_t k =2; k < 3; k++)
	{
		robustMode = k;
		PrcOpt.outliersnum = 3;
		std::stringstream oss;
		std::string str;
		char* tmpSln;
		if (0 == robustMode)
		{
			PrcOpt.robustopt = 0;
			oss << "..\\datas\\TESTWLS.pos";
		}
		if (1 == robustMode)//IGGIII
		{
			PrcOpt.robustopt = 1;
			PrcOpt.iggiiiparams[0] = 1.5;
			PrcOpt.iggiiiparams[1] = 3;
			oss << "..\\datas\\IGGIIINEw.pos";
		}
		else if (2 == robustMode)//mRANSAC
		{
			PrcOpt.robustopt = 2;
			oss << "..\\datas\\RANSAC1_0909.pos";
		}
		str = oss.str();
		tmpSln = (char*)(str.c_str());
		std::printf("%s\r\n", tmpSln);
		auto now = std::chrono::steady_clock::now();
		for (int j = 0; j < 1; j++)
			postpos(st, st, 0, 0, &PrcOpt, &SolOpt, &FileOpt, infile, 2, tmpSln, NULL, NULL);
		auto t2 = std::chrono::steady_clock::now();
		auto time_span = std::chrono::duration_cast<std::chrono::duration<double>>(t2 - now);
		double time_during = time_span.count() ;
		printf("%.2f  Finish \r\n", time_during);
	}



#else

#endif







	return 1;
}

