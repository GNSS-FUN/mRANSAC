#pragma once
#include"rtklib.h"
#include <memory>
#include <set>
#include <vector>
constexpr int sampleSize = 4 + ENACMP + ENAGAL + ENAGLO + ENAIRN;//sampleSize>=estimateNum
constexpr int estimateNum = 4 + ENACMP + ENAGAL + ENAGLO + ENAIRN;//the size of params
class RansacWithGNSS
{
public:
	double max_iterations_;
	double  min_iterations_;
	double probability_;
	double ransac_p;
	double threshold;
	bool sort_by_p;
	bool reCal;
	RansacWithGNSS();
	int satIndexBest[sampleSize] = { 0 };
	double best_model_value_;
	double best_error_;
	int thresholdMethod;//0:manual 1:auto
	double multiThreshold;
	int checkType;//criterion default: number of satellites 1:posterior variance with weights  2: satellite weights 3: spatial accuracy factor 4: posterior variance
	bool useCoRelation;
	bool useSys;
	bool useSample;
	bool locOpt;//Locally Optimized
	bool useDOP;
	double bestDx[estimateNum];
	int min_true_itr;
	double min_inlier_;//if inlier>=min_inlier&&locOpt 
	std::unique_ptr<bool[]>best_result_;//the result of each sat
	int calRANSAC(const double* H, const  double* V, const  double* P, const  double* x,int &satNum, const  double* azel, int* sat, std::vector< std::set<int>>samples,int sys);
	bool calSample(const double* H, const double* V, const double* P, int* sample, double* DX=nullptr, double* D0=nullptr);
	bool checkParam(const double* H, const  double* P, const  double* V, double* D0);
	std::unique_ptr<double[]>best_res;//the res of each sat from best mns
	std::unique_ptr<double[]>best_d;//the res of each sat from best mns
	std::unique_ptr<double[]> now_d;//the res of each sat from best mns

	int repeat();
private:
	double now_model_value;
	double now_error;
	int sat_num;
	int k0 , k1, k3, itr_count;
	std::unique_ptr<bool[]>now_result;//the result of each sat
	std::unique_ptr<double[]>satCor;
	void update_iter();
	int calSamples(const double* H, const double* V, const double* P, const double* x, const double* azel, const int* sat, std::vector< std::set<int>>samples, int sys);
	int calSmallSize(const double* H, const double* V, const double* P, const  double* x, const  double* azel, const  int* sat, int sys, int num);
	int calLargeSize(const double* H, const double* V, const double* P, const  double* x, const double* azel, const int* sat, int sys, int num);
};

